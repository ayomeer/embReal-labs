#pragma once
#ifdef __cplusplus
extern "C" {
#endif

void cpp_main();

#ifdef __cplusplus
}
#endif
